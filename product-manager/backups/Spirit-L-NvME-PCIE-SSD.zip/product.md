# VERICO SPIRIT-L NVMe M.2 Solid State Drive
Hero Background: global/ssd-hero.jpg
Category: ssd
Catalog Image: images/Spirit-L-main.png
Badge: premium
Featured Rank: 1

Short Description: Blazing Performance; Friendly Price! With superb cost to performance ratio, VERICO SPIRIT-L is the best upgrade choice for super fast M.2 SSD performance with friendly prices. Be ready to be impressed by the amazing read/write speed performance!

## Images
- images/Product-1.png
- images/Product-2.png
- images/Product-3.png
- images/Product-4.png
- images/Product-5.png
- images/Product-6.png
## Features
- Blazing performance: up to 3200MB/s read, 2300MB/s write speeds
- PCIe 3.0 x4 with NVMe 1.3 in2300ace for excellent speed
- M.2 2280 form factor for modern devices
- Compact 80 x 22 x 3.8mm design
- Multiple capacity options from 128GB to 2TB
- Up to 180,000 IOPS for both read and write operations
- Friendly price with superb cost to performance ratio
- Compatible with Windows 7-10, Vista, and Linux

## Specification
- Interface: PCIe 3.0 x4 with NVMe 1.3
- Form Factor: M.2 2280
- Dimensions: 80 x 22 x 3.8 mm
- Voltage: DC 3.3V
- Capacities: 128GB, 256GB, 512GB, 1TB, 2TB
- Read Speed: Up to 3200MB/s
- Write Speed: Up to 2300MB/s
- Read IOPS: Up to 180,000
- Write IOPS: Up to 180,000
- OS Support: Windows 7-10, Windows Vista, Linux 2.6.33 or newer

## Detailed Features
### Blazing Performance; Friendly Price!
Image: images/feature-1.png
With superb cost to performance ratio, VERICO SPIRIT-L is the best upgrade choice for super fast M.2 SSD performance with friendly prices.
Benefits:
- Up to 3200MB/s read speed
- Up to 12300B/s write speed
- Excellent value for money
- Perfect for budget-conscious users

### Be Ready for the Speed!
Image: images/feature-2.png
Be ready to be impressed by the amazing read/write speed performance that VERICO SPIRIT-L M.2 SSD provides! You will never go back to traditional hard drives again!
Benefits:
- Up to 180,000 IOPS for read operations
- Up to 180,000 IOPS for write operations
- Impressive data processing speed
- Superior to traditional hard drives

### Discreet, Yet Powerful
Image: images/feature-3.png
The VERICO SPIRIT-L is in compliance with PCIe Gen. 3 x2 and NVMe 1.3: discreetly hidden on your motherboard, yet offers blazing performance.
Benefits:
- PCIe 3.0 x4 with NVMe 1.3 interface
- Discreet motherboard installation
- Blazing performance in compact form
- Modern NVMe technology

## Compatibility
Title: Device Compatibility
Subtitle: Compatible with devices supporting M.2 NVMe SSD storage.
- Desktop computers
  Icon: icons/icon-desktop.svg
- Laptops & Ultrabooks
  Icon: icons/icon-laptop.svg
- Mini PCs & NUCs
  Icon: icons/icon-laptop.svg
- Gaming systems
  Icon: icons/icon-gamepads.svg

## Package Content
Title: Package Content
Subtitle: What's in the box
- 1 × VERICO SPIRIT-L NVMe M.2 SSD
  Icon: images/Product-1.png


## Also Available In
### VERICO SPIRIT-L 128GB
Package Image: images/Spirit-L-128.png
Model Name: Spirit-L Gen 3 x 4 128GB
SKU: 1SSOK-SSMMC3-NN
EAN: 4713095608339
- 1 × VERICO SPIRIT-L NVMe M.2 SSD 128GB

### VERICO SPIRIT-L 256GB
Package Image: images/Spirit-L-256.png
Model Name: Spirit-L Gen 3 x 4 256GB
SKU: 1SSOK-SSMM93-NN
EAN: 4713095608346
- 1 × VERICO SPIRIT-L NVMe M.2 SSD 256GB

### VERICO SPIRIT-L 512GB
Package Image: images/Spirit-L-512.png
Model Name: Spirit-L Gen 3 x 4 512GB
SKU: 1SSOK-SSMMA3-NN
EAN: 4713095608353
- 1 × VERICO SPIRIT-L NVMe M.2 SSD 512GB

### VERICO SPIRIT-L 1TB
Package Image: images/Spirit-L-1TB.png
Model Name: Spirit-L Gen 3 x 4 1TB
SKU: 1SSOK-SSMMG3-NN
EAN: 4713095608360
- 1 × VERICO SPIRIT-L NVMe M.2 SSD 1TB

### VERICO SPIRIT-L 2TB
Package Image: images/Spirit-L-2TB.png
Model Name: Spirit-L Gen 3 x 4 2TB
SKU: 1SSOK-SSMMH3-NN
EAN: 4713095608421
- 1 × VERICO SPIRIT-L NVMe M.2 SSD 2TB