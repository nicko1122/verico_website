# VERICO Phantom 3D NAND SSD
Hero Background: global/ssd-hero.jpg
Category: ssd
Catalog Image: images/Phantom-main.png
Badge: premium
Featured Rank: 1

Short Description: The VERICO Phantom 3D NAND SSD delivers ultra-fast performance with up to 550MB/s read speeds and 500MB/s write speeds. Featuring SLC Cache technology, advanced data protection, and a slim 7mm form factor for seamless upgrades across desktops, laptops, and gaming consoles.

## Images
- images/Product-1.png
- images/Product-2.png

## Features
- Ultra-fast performance: up to 550MB/s read, 500MB/s write speeds
- Turbo-Boost SLC Cache technology for consistent high speeds
- 100% solid-state design: shock- and vibration-proof
- Advanced data protection with TRIM, ECC, RAID capability, and S.M.A.R.T. monitoring
- Premium 3D NAND Flash with high-quality controller
- Slim 7mm ultra-thin form factor for broad compatibility
- 3-year warranty with rigorous quality testing

## Specification
- Interface: SATA3 6Gb/s (backward compatible with SATA II)
- Form Factor: 2.5", 7mm ultra-thin
- Dimensions: 69 x 100.2 x 7 mm
- Weight: 77g
- Capacities: 120GB, 240GB, 480GB, 960GB, 2TB
- Read Speed: Up to 550MB/s (all capacities)
- Write Speed: Up to 500MB/s (240GB/480GB/960GB/2TB), 430MB/s (120GB)

## Detailed Features
### Ultra-Fast Performance
Image: images/feature-1.png
Delivers exceptional read and write speeds for rapid data access and transfer.
Benefits:
- Up to 550MB/s read speed (all capacities)
- Up to 500MB/s write speed (240GB/480GB/960GB/2TB), 430MB/s (120GB)
- High-speed SATA3 6Gb/s interface

### Advanced Data Protection
Image: images/feature-2.png
Advanced protection features ensure data integrity and device safety.
Benefits:
- 100% solid-state design: shock- and vibration-proof, no moving parts
- Advanced data protection: TRIM command, ECC, RAID capability, and S.M.A.R.T. monitoring

### Broad Compatibility
Image: images/feature-3.png
Slim design fits most devices for easy installation and instant performance boost.
Benefits:
- Slim 7mm ultra-thin form factor
- Compatible with most desktops, laptops (including Ultrabooks)
- PlayStation 4/4 Pro compatible (240GB and above)
- Simple installation process

## Compatibility
Title: Device Compatibility
Subtitle: Compatible with most devices requiring 2.5" SATA SSD storage.
- Desktop computers
  Icon: icons/icon-desktop.svg
- Laptops & Ultrabooks
  Icon: icons/icon-laptop.svg
- Gaming consoles (PS4/PS4 Pro)
  Icon: icons/icon-gamepads.svg
- External storage enclosures
  Icon: icons/icon-storage.svg

## Package Content
Title: Package Content
Subtitle: What's in the box
- 1 × VERICO Phantom 3D NAND SSD
  Icon: images/Product-1.png


## Also Available In
### VERICO Phantom 120GB
Package Image: images/Phantom-120.png
Model Name: Solid State Drive/Verico Phantom Series/SATA III 6Gb/s 120GB/Black/Retail
SKU: 1SSOP-SSBKI3-NN
EAN: 4713095605390
- 1 × VERICO Phantom 3D NAND SSD 120GB

### VERICO Phantom 128GB
Package Image: images/Phantom-128.png
Model Name: Solid State Drive/Verico Phantom Series/SATA III 6Gb/s 128GB/Black/Retail
SKU: 1SSOP-SSBKQ3-NN
EAN: 4713095609046
- 1 × VERICO Phantom 3D NAND SSD 128GB

### VERICO Phantom 240GB
Package Image: images/Phantom-240.png
Model Name: Solid State Drive/Verico Phantom Series/SATA III 6Gb/s 240GB/Black/Retail
SKU: 1SSOP-SSBKJ3-NN
EAN: 4713095605406
- 1 × VERICO Phantom 3D NAND SSD 240GB

### VERICO Phantom 256GB
Package Image: images/Phantom-256.png
Model Name: Solid State Drive/Verico Phantom Series/SATA III 6Gb/s 256GB/Black/Retail
SKU: 1SSOP-SSBKK3-NN
EAN: 4713095609053
- 1 × VERICO Phantom 3D NAND SSD 256GB

### VERICO Phantom 480GB
Package Image: images/Phantom-480.png
Model Name: Solid State Drive/Verico Phantom Series/SATA III 6Gb/s 480GB/Black/Retail
SKU: 1SSOP-SSBKL3-NN
EAN: 4713095605413
- 1 × VERICO Phantom 3D NAND SSD 480GB

### VERICO Phantom 512GB
Package Image: images/Phantom-512.png
Model Name: Solid State Drive/Verico Phantom Series/SATA III 6Gb/s 512GB/Black/Retail
SKU: 1SSOP-SSBKM3-NN
EAN: 4713095609060
- 1 × VERICO Phantom 3D NAND SSD 512GB

### VERICO Phantom 960GB
Package Image: images/Phantom-960.png
Model Name: Solid State Drive/Verico Phantom Series/SATA III 6Gb/s 960GB/Black/Retail
SKU: 1SSOP-SSBKN3-NN
EAN: 4713095605437
- 1 × VERICO Phantom 3D NAND SSD 960GB

### VERICO Phantom 1TB
Package Image: images/Phantom-1TB.png
Model Name: Solid State Drive/Verico Phantom Series/SATA III 6Gb/s 1TB/Retail
SKU: 1SSOP-SSBKO3-NN
EAN: 4713095609268
- 1 × VERICO Phantom 3D NAND SSD 1TB

### VERICO Phantom 2TB
Package Image: images/Phantom-2TB.png
Model Name: Solid State Drive/Verico Phantom Series/SATA III 6Gb/s 2TB/Black/Retail
SKU: 1SSOP-SSBKP3-NN
EAN: 4713095605444
- 1 × VERICO Phantom 3D NAND SSD 2TB