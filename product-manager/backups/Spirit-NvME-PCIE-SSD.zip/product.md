# VERICO SPIRIT NVMe M.2 Solid State Drive
Hero Background: global/ssd-hero.jpg
Category: ssd
Catalog Image: images/Spirit-main.png
Badge: premium
Featured Rank: 1

Short Description: Ultimate Performance; Awesome Value! The VERICO SPIRIT NVMe M.2 SSD offers speed beyond belief with up to 3470MB/s read and 3000MB/s write speeds. With awesome cost to performance ratio, it's the best M.2 SSD ultimate upgrade choice for those who seek life in the fast lane!

## Images
- images/Product-1.png
- images/Product-2.png
- images/Product-3.png
- images/Product-4.png
- images/Product-5.png
## Features
- Ultimate performance: up to 3470MB/s read, 3000MB/s write speeds
- PCIe 3.0 x4 with NVMe 1.3 interface for maximum speed
- 3D NAND TLC flash technology for reliability
- M.2 2280 form factor for modern devices
- Compact 80 x 22 x 3.8mm design
- Multiple capacity options from 256GB to 2TB
- Up to 600,000 IOPS for both read and write operations
- Compatible with Windows 7-10, Vista, and Linux

## Specification
- Interface: PCIe 3.0 x4 with NVMe 1.3
- Form Factor: M.2 2280
- Dimensions: 80 x 22 x 3.8 mm
- Voltage: DC 3.3V
- Capacities: 256GB, 512GB, 1TB, 2TB
- Read Speed: Up to 3470MB/s
- Write Speed: Up to 3000MB/s
- Read IOPS: Up to 600,000
- Write IOPS: Up to 600,000
- Flash Type: 3D NAND TLC
- MTBF: 2M Hours
- OS Support: Windows 7-10, Windows Vista, Linux 2.6.33 or newer

## Detailed Features
### Ultimate Performance; Awesome Value!
Image: images/feature-1.png
With awesome cost to performance ratio, VERICO Spirit is the best M.2 SSD ultimate upgrade choice for those who seek life in the fast lane!
Benefits:
- Up to 3470MB/s read speed
- Up to 3000MB/s write speed
- Exceptional value for money
- Perfect for performance enthusiasts

### Can You Handle the Speed?!
Image: images/feature-2.png
The VERICO Spirit M.2 SSD offers speed beyond belief! WARNING! You will need to work super fast to prevent your computer getting impatient!
Benefits:
- Up to 600,000 IOPS for read operations
- Up to 600,000 IOPS for write operations
- Lightning-fast data processing
- Unmatched performance

### Discreet, Yet Powerful
Image: images/feature-3.png
The VERICO Spirit SSD is in compliance with PCIe Gen. 3 x4 and NVMe 1.3: discreetly hidden on your motherboard, yet offers astounding performance.
Benefits:
- PCIe 3.0 x4 with NVMe 1.3 interface
- Discreet motherboard installation
- Astounding performance in compact form
- 3D NAND TLC flash technology

## Compatibility
Title: Device Compatibility
Subtitle: Compatible with devices supporting M.2 NVMe SSD storage.
- Desktop computers
  Icon: icons/icon-desktop.svg
- Laptops & Ultrabooks
  Icon: icons/icon-laptop.svg
- Mini PCs & NUCs
  Icon: icons/icon-laptop.svg
- Gaming systems
  Icon: icons/icon-gamepads.svg

## Package Content
Title: Package Content
Subtitle: What's in the box
- 1 × VERICO SPIRIT NVMe M.2 SSD
  Icon: images/Product-1.png


## Also Available In
### VERICO SPIRIT 256GB
Package Image: images/Spirit-256.png
Model Name: Verico SPIRIT Gen 3 x 4 256GB
SKU: 1SSOS-SSMBK3-NN
EAN: 4713095606311
- 1 × VERICO SPIRIT NVMe M.2 SSD 256GB

### VERICO SPIRIT 512GB
Package Image: images/Spirit-512.png
Model Name: Verico SPIRIT Gen 3 x 4 512GB
SKU: 1SSOS-SSMBM3-NN
EAN: 4713095606328
- 1 × VERICO SPIRIT NVMe M.2 SSD 512GB

### VERICO SPIRIT 1TB
Package Image: images/Spirit-1TB.png
Model Name: Verico SPIRIT Gen 3 x 4 1TB
SKU: 1SSOS-SSMBO3-NN
EAN: 4713095606335
- 1 × VERICO SPIRIT NVMe M.2 SSD 1TB

### VERICO SPIRIT 2TB
Package Image: images/Spirit-2TB.png
Model Name: Verico SPIRIT Gen 3 x 4 2TB
SKU: 1SSOS-SSMBP3-NN
EAN: 4713095606342
- 1 × VERICO SPIRIT NVMe M.2 SSD 2TB