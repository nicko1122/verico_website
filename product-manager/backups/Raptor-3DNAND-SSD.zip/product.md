# VERICO Raptor M.2 SATA3 SSD
Hero Background: global/ssd-hero.jpg
Category: ssd
Catalog Image: images/Raptor-main.png
Badge: premium
Featured Rank: 1

Short Description: Welcome to the Fast World! The VERICO Raptor M.2 2280 SATA3 SSD delivers amazing read/write speeds with SATA3 6Gb/s interface and Turbo-Boost SLC Cache technology. Experience a whole different computer performance that you will never want to go back from.

## Images
- images/Product-1.png
- images/Product-2.png
- images/Product-3.png
- images/Product-4.png
- images/Product-5.png
- images/Product-6.png
## Features
- Ultra-fast performance: up to 550MB/s read, 500MB/s write speeds
- Turbo-Boost SLC Cache technology for enhanced work efficiency
- M.2 2280 form factor for modern devices
- SATA III 6Gb/s interface for maximum compatibility
- Compact 80 x 22 x 3.8mm design
- Multiple capacity options from 128GB to 2TB
- Compatible with Windows 7-10, Vista, and Linux

## Specification
- Interface: SATA III 6Gb/s
- Form Factor: M.2 2280
- Dimensions: 80 x 22 x 3.8 mm
- Voltage: DC 3.3V
- Capacities: 128GB, 256GB, 512GB, 1TB, 2TB
- Read Speed: Up to 550MB/s (all capacities)
- Write Speed: Up to 500MB/s (256GB/512GB/1TB/2TB), 450MB/s (128GB)
- OS Support: Windows 7-10, Windows Vista, Linux 2.6.33 or newer

## Detailed Features
### Welcome to the Fast World
Image: images/feature-1.png
Experience a whole different computer performance with amazing read/write speeds and SATA3 6Gb/s interface.
Benefits:
- Up to 550MB/s read speed (all capacities)
- Up to 500MB/s write speed (256GB/512GB/1TB/2TB), 450MB/s (128GB)
- High-speed SATA III 6Gb/s interface

### Turbo-Boost SLC Cache Technology
Image: images/feature-2.png
Integrated SLC Cache technology turbo-boosts all data input, enhancing your work efficiency.
Benefits:
- Accelerated data processing
- Enhanced work efficiency
- Consistent high performance

### Modern M.2 Form Factor
Image: images/feature-3.png
Compact M.2 2280 design perfect for modern laptops, desktops, and mini PCs.
Benefits:
- Compact 80 x 22 x 3.8mm design
- Perfect for modern devices
- Easy installation
- Space-saving solution

## Compatibility
Title: Device Compatibility
Subtitle: Compatible with devices supporting M.2 SATA SSD storage.
- Desktop computers
  Icon: icons/icon-desktop.svg
- Laptops & Ultrabooks
  Icon: icons/icon-laptop.svg
- Mini PCs & NUCs
  Icon: icons/icon-laptop.svg
- Gaming systems
  Icon: icons/icon-gamepads.svg

## Package Content
Title: Package Content
Subtitle: What's in the box
- 1 × VERICO Raptor M.2 SATA3 SSD
  Icon: images/Product-1.png


## Also Available In
### VERICO Raptor 128GB
Package Image: images/Raptor-128.png
Model Name: Raptor M.2 2280 SATA III 128GB
SKU: 1SSOR-SSM2Q3-NN
EAN: 4713095608377
- 1 × VERICO Raptor M.2 SATA3 SSD 128GB

### VERICO Raptor 256GB
Package Image: images/Raptor-256.png
Model Name: Raptor M.2 2280 SATA III 256GB
SKU: 1SSOR-SSM2K3-NN
EAN: 4713095608384
- 1 × VERICO Raptor M.2 SATA3 SSD 256GB

### VERICO Raptor 512GB
Package Image: images/Raptor-512.png
Model Name: Raptor M.2 2280 SATA III 512GB
SKU: 1SSOR-SSM2M3-NN
EAN: 4713095608391
- 1 × VERICO Raptor M.2 SATA3 SSD 512GB

### VERICO Raptor 1TB
Package Image: images/Raptor-1TB.png
Model Name: Raptor M.2 2280 SATA III 1TB
SKU: 1SSOR-SSM2O3-NN
EAN: 4713095608407
- 1 × VERICO Raptor M.2 SATA3 SSD 1TB

### VERICO Raptor 2TB
Package Image: images/Raptor-2TB.png
Model Name: Raptor M.2 2280 SATA III 2TB
SKU: 1SSOR-SSM2H3-NN
EAN: 4713095608414
- 1 × VERICO Raptor M.2 SATA3 SSD 2TB